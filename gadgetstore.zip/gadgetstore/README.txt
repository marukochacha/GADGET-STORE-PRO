GADGET STORE PRO — Struktur Proyek untuk Laragon
==================================================

Struktur folder:
gadgetstore/
├── index.html        <- halaman utama (HTML murni)
├── css/
│   └── style.css      <- semua styling
├── js/
│   └── script.js       <- semua logika aplikasi
└── assets/             <- taruh gambar & video produk di sini
    ├── ipad.jpg
    ├── ipad.mp4
    ├── iphone 15.jpg
    ├── iphone.mp4
    ├── case.jpg
    ├── case.mp4
    ├── macbook.jpg
    └── VID MACBOOK.mp4

CARA PAKAI DI LARAGON
----------------------
1. Buka folder Laragon kamu, biasanya di: C:\laragon\www
2. Copy seluruh folder "gadgetstore" ini ke dalam C:\laragon\www
   Jadi hasilnya: C:\laragon\www\gadgetstore\index.html
3. Taruh file gambar & video produk kamu ke dalam folder "assets"
   (nama file harus persis sama seperti yang tertulis di atas,
   termasuk spasi pada "iphone 15.jpg" dan "VID MACBOOK.mp4")
4. Jalankan Laragon, klik tombol "Start All"
5. Klik kanan folder "gadgetstore" di Laragon (menu Laragon di system tray
   atau lewat "www" di aplikasi Laragon) lalu pilih "Open with browser 100"
   ATAU langsung buka di browser: http://localhost/gadgetstore/

CATATAN
-------
- Login admin demo: username "admin", password "admin123"
- Data akun pembeli & pesanan disimpan browser (localStorage), bukan database.
  Jadi kalau ganti browser/device, datanya tidak akan sama.
- Kalau mau pakai database sungguhan (MySQL via Laragon), ini perlu dikembangkan
  lagi dengan backend PHP — beri tahu saya kalau kamu mau saya bantu bikin itu.
